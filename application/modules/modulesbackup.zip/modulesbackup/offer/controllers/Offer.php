<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Offer extends Common_Controller { 
  public $data = array();
  public $file_data = "";
  public $element = array();
  public function __construct() {
    parent::__construct();
    $this->is_auth_admin();
  }

     /**
     * @method index
     * @description listing display
     * @return array
     */
     public function index() {
      $this->data['parent'] = "Offer";
      $this->data['title'] = "Offer";
      $option = array('table' => OFFERS .' as offer',
        'select' => '*',
        'order' => array('offer.id' => 'DESC'),
        );

      $this->data['list'] = $this->common_model->customGet($option);

     
      $this->load->admin_render('list', $this->data, 'inner_script');
    }
   
    /**
     * @method open_model
     * @description load model box
     * @return array
     */

    function open_model() {
      $this->data['title'] = lang("add_offer");
       $option =array(
        'table' => USERS,
        'select'=> '*',
        'where' => array('id!='=>1)
        );
      $this->data['users']= $this->common_model->customGet($option);
      $this->load->view('add', $this->data);
    }

    

    /**
     * @method cms_add
     * @description add dynamic rows
     * @return array
     */
    public function offer_add() {

      $this->form_validation->set_rules('offer_name', lang('offer_name'), 'required|trim');
     

      if ($this->form_validation->run() == true) {

        $offer_name = $this->input->post('offer_name');
        $description = $this->input->post('description');
        //$user_id = $this->input->post('user_id');
        $from_date = date('Y-m-d',strtotime($this->input->post('from_date')));
        $to_date = date('Y-m-d',strtotime($this->input->post('to_date')));
        
        $offer_name = $this->security->xss_clean($offer_name);
        $description = $this->security->xss_clean($description);
        $notification_type = $this->input->post('notification');
        $options_data = array(

          'offer_name'    => $offer_name,
          'description'   => $description,
          'from_date'     => $from_date,
          'to_date'       => $to_date,
          'created_date'  => datetime(),
          'status'        => 1,
          );

        $option = array('table' => OFFERS, 'data' => $options_data);
        $offer_id = $this->common_model->customInsert($option);

        if($notification_type == 1) {

           $option = array('table' => USERS,
           'select' => 'id',
           'where'=>array('user_type'=>'USER')
          );
           $user_id = $this->common_model->customGet($option);

          foreach ($user_id as $key => $value) {
            $all_users[] = $value->id;
          }  
                      /* Insert Notification Request */  
                     $notification_arr = array(
                                            'message' => $offer_name,
                                            'title' => 'Offer',
                                            'type_id' => $offer_id,
                                            'user_ids' => serialize($all_users),
                                            'notification_type' => 'Offer',
                                            'sent_time' => datetime()
                                        );
                     $lid = $this->common_model->insertData(ADMIN_NOTIFICATION,$notification_arr);

                     /* Insert Loyalty Offers & Notifications */
                     $offers     = array();
                     $user_notifications = array();
                     for($i=0;$i<count($all_users);$i++)
                     {

                      $option = array(
                              'offer_id'=>$offer_id,
                              'user_id'=>$all_users[$i],
                              'created_date'=>datetime()
                                
                            );
                        array_push($offers, $option);

                        $insertArray = array(
                            'type_id' => $offer_id,
                            'sender_id' => ADMIN_ID,
                            'reciever_id' => $all_users[$i],
                            'notification_type' => 'Offer',
                            'title' => 'Offer',
                            'notification_parent_id' => $lid,
                            'message' => $offer_name,
                            'is_read' => 0,
                            'is_send' => 0,
                            'sent_time' => date('Y-m-d H:i:s'),
                        );
                        array_push($user_notifications, $insertArray);
                     }

                     if(!empty($offers)){
                        $this->common_model->insertBulkData(USER_OFFERS,$offers);
                     }

                     if(!empty($user_notifications)){
                        $this->common_model->insertBulkData(USER_NOTIFICATION,$user_notifications);
                     }

                }else if ($notification_type == 2) {

                   $option = array('table' => USER_MEMBERSHIP,
                     'select' => 'user_id',
                     'where'=> array('membership_type'=>'PREMIUM')
                    );

                    $user_id = $this->common_model->customGet($option);
                   if(!empty($user_id)){
                      foreach ($user_id as $key => $value) {
                        $premium_users[] = $value->user_id;
                      }

                       /* Insert Notification Request */  
                     $notification_arr = array(
                                            'message' => $offer_name,
                                            'title' => 'Offer',
                                            'type_id' => $offer_id,
                                            'user_ids' => serialize($premium_users),
                                            'notification_type' => 'Offer',
                                            'sent_time' => datetime()
                                        );
                     $lid = $this->common_model->insertData(ADMIN_NOTIFICATION,$notification_arr);

                     /* Insert Notifications */
                      $offers     = array();
                     $user_notifications = array();
                     for($i=0;$i<count($premium_users);$i++)
                     {

                      $option = array(
                              'offer_id'=>$offer_id,
                              'user_id'=>$premium_users[$i],
                              'created_date'=>datetime()
                                
                            );
                        array_push($offers, $option);
                      
                        $insertArray = array(
                            'type_id' => $offer_id,
                            'sender_id' => ADMIN_ID,
                            'reciever_id' => $premium_users[$i],
                            'notification_type' => 'Offer',
                            'title' => 'Offer',
                            'notification_parent_id' => $lid,
                            'message' => $offer_name,
                            'is_read' => 0,
                            'is_send' => 0,
                            'sent_time' => date('Y-m-d H:i:s'),
                        );
                        array_push($user_notifications, $insertArray);
                     }

                     if(!empty($offers)){
                        $this->common_model->insertBulkData(USER_OFFERS,$offers);
                     }

                     if(!empty($user_notifications)){
                        $this->common_model->insertBulkData(USER_NOTIFICATION,$user_notifications);
                     }
                        
                    }
                    
                }
        if($offer_id) {


          $response = array('status' => 1, 'message' => lang('offer_success'), 'url' => base_url('offer'));

        }else {
          $response = array('status' => 0, 'message' => lang('offer_failed'));
        } 
      }
     else {
      $messages = (validation_errors()) ? validation_errors() : '';
      $response = array('status' => 0, 'message' => $messages);
    }
    echo json_encode($response);
  }

    /**
     * @method cms_edit
     * @description edit dynamic rows
     * @return array
     */
    public function offer_edit() {
      $this->data['title'] = lang("edit_offer");
      $id = decoding($this->input->post('id'));
      if (!empty($id)) {

        $option = array(
          'table' => OFFERS,
          'where' => array('id' => $id),
          'single' => true
          );
        $results_row = $this->common_model->customGet($option);
        if (!empty($results_row)) {
          $this->data['results'] = $results_row;
          $this->load->view('edit', $this->data);
        } else {
          $this->session->set_flashdata('error', lang('not_found'));
          redirect('offer');
        }
      } else {
        $this->session->set_flashdata('error', lang('not_found'));
        redirect('offer');
      }
    }

    /**
     * @method cms_update
     * @description update dynamic rows
     * @return array
     */
    public function offer_update() {

      $this->form_validation->set_rules('offer_name', lang('offer_name'), 'required|trim');

      $where_id = $this->input->post('id');
      if ($this->form_validation->run() == FALSE):
        $messages = (validation_errors()) ? validation_errors() : '';
      $response = array('status' => 0, 'message' => $messages);
      else:
        $this->filedata['status'] = 1;
      $image = $this->input->post('exists_image');

      if (!empty($_FILES['image']['name'])) {
        $this->filedata = $this->commonUploadImage($_POST, 'product', 'image');

        if ($this->filedata['status'] == 1) {
         $image = $this->filedata['upload_data']['file_name'];
         delete_file($this->input->post('exists_image'), FCPATH."uploads/product/");


       }

     }

     if ($this->filedata['status'] == 0) {
      $response = array('status' => 0, 'message' => $this->filedata['error']);  
    }else{

        $offer_name  = $this->input->post('offer_name');
        $description = $this->input->post('description');
        $from_date   = date('Y-m-d',strtotime($this->input->post('from_date')));
        $to_date     = date('Y-m-d',strtotime($this->input->post('to_date')));
        
        $offer_name  = $this->security->xss_clean($offer_name);
        $description = $this->security->xss_clean($description);
      
      
       $options_data = array(

          'offer_name'    => $offer_name,
          'description'   => $description,
          'from_date'     => $from_date,
          'to_date'       => $to_date
          );
      $option = array(
        'table' => OFFERS,
        'data' => $options_data,
        'where' => array('id' => $where_id)
        );
      $update = $this->common_model->customUpdate($option);
      $response = array('status' => 1, 'message' => lang('offer_success_update'), 'url' => base_url('offer'));
   
}

    endif;

    echo json_encode($response);
  }

  function del() {
        $response = "";
        $id = decoding($this->input->post('id')); // delete id
        $table = $this->input->post('table'); //table name
        $id_name = $this->input->post('id_name'); // table field name
        if (!empty($table) && !empty($id) && !empty($id_name)) { 

            $option = array(
                'table' => $table,
                'where' => array($id_name => $id)
            );
            $delete = $this->common_model->customDelete($option);
            if ($delete) {
                $response = 200;
            } else
                $response = 400;
        }else {
            $response = 400;
        }
        echo $response;
    }



}
