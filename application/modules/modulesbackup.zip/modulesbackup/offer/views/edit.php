<style> 
    .modal-footer .btn + .btn {
    margin-bottom: 5px !important;
    margin-left: 5px;
}
</style> 
<div id="commonModal" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <form class="form-horizontal" role="form" id="addFormAjax" method="post" action="<?php echo base_url('offer/offer_update') ?>" enctype="multipart/form-data">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                    <h4 class="modal-title"><?php echo (isset($title)) ? ucwords($title) : "" ?></h4>
                </div>
                <div class="modal-body">
                    <div class="loaders">
                        <img src="<?php echo base_url().'assets/images/Preloader_3.gif';?>" class="loaders-img" class="img-responsive">
                    </div>
                    <div class="alert alert-danger" id="error-box" style="display: none"></div>
                    <div class="form-body">
                        <div class="row">
                         <div class="col-md-12" >
                                <div class="form-group">
                                    <label class="col-md-3 control-label"><?php echo lang('offer_name');?></label>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control" name="offer_name" id="offer_name" placeholder="<?php echo lang('offer_name');?>" value="<?php echo $results->offer_name;?>" />
                                    </div>
                                    </div>
                                </div>


                                <div class="col-md-12" >
                                 <div class="form-group">
                                    <label class="col-md-3 control-label"><?php echo lang('description');?></label>
                                    <div class="col-md-9">
                                        <textarea class="form-control" name="description" id="description" placeholder="<?php echo lang('description');?>"><?php echo $results->description;?></textarea>
                                    </div>
                                    </div>
                                </div>

                                 <div class="col-md-12" >
                                    
                                        <div class="form-group">
                                            <label class="col-md-3 control-label"><?php echo lang('from_date'); ?></label>
                                            <div class="col-md-9">
                                                <input type="text" class="form-control" name="from_date" id="from_date" placeholder="<?php echo lang('from_date'); ?>" readonly="" value="<?php echo $results->from_date;?>"/>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="col-md-12" >
                                        <div class="form-group">
                                            <label class="col-md-3 control-label"><?php echo lang('to_date'); ?></label>
                                            <div class="col-md-9">
                                                <input type="text" class="form-control" name="to_date" id="to_date" placeholder="<?php echo lang('to_date'); ?>" readonly="" value="<?php echo $results->to_date;?>"/>
                                            </div>
                                        </div>
                                    </div>
                               

                             
                            <input type="hidden" name="id" value="<?php echo $results->id;?>" />
                           
                           
                            <div class="space-22"></div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
                    <button type="submit" id="submit" class="btn btn-primary">Update</button>
                </div>
            </form>
        </div> <!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>
<script>
$(document).ready(function(){
$('#category_id').select2();
});

$("#prelaunch_date").datepicker({
                todayBtn: "linked",
                format: 'yyyy/mm/dd',
                keyboardNavigation: false,
                forceParse: false,
                calendarWeeks: true,
                autoclose: true,
                startDate: '-0m'
            });
</script>