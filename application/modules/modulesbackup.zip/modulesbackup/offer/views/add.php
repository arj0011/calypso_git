<style>
    .modal-footer .btn + .btn {
        margin-bottom: 5px !important;
        margin-left: 5px;
    }
</style>
<div id="commonModal" class="modal fade" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <form class="form-horizontal" role="form" id="addFormAjax" method="post" action="<?php echo base_url('offer/offer_add') ?>" enctype="multipart/form-data">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal"><span aria-hidden="true">&times;</span><span class="sr-only">Close</span></button>
                    <h4 class="modal-title"><?php echo (isset($title)) ? ucwords($title) : "" ?></h4>
                </div>
                <div class="modal-body"> 
                    <div class="loaders">
                        <img src="<?php echo base_url().'assets/images/Preloader_3.gif';?>" class="loaders-img" class="img-responsive">
                    </div>
                    <div class="alert alert-danger" id="error-box" style="display: none"></div>
                    <div class="form-body">
                        <div class="row">
                          
                            

                           <div class="col-md-12" >
                            <div class="form-group ">
                                <label class="col-lg-3 control-label"> 
                                    <?php echo lang('select_option'); ?></label>
                                    <div class="col-md-9">
                                        <div class="custom_chk chk_box">
                                          <div class="checkbox">
                                            <input type="radio" class="all_user" name="notification" value="2"><label class="checkbox-inline"><?php echo lang('premium_users'); ?></label>
                                        </div>
                                        
                                        <div class="checkbox">
                                            <input type="radio" class="all_user" name="notification" value="1" checked><label class="checkbox-inline"> <?php echo lang('all_users'); ?></label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>  

                           <!--  <div class="col-md-12" >
                                <div class="form-group">
                                    <label class="col-md-3 control-label"><?php echo lang('select_user');?></label>
                                    <div class="col-md-9">
                                       <select class="" name="user_id[]" id="user_id" style="width:100%" multiple="">
                                        <?php if(!empty($users)){foreach($users as $user){?>
                                        <option value="<?php echo $user->id;?>"><?php echo $user->full_name." (".$user->email.")";?></option>
                                        <?php }}?>
                                      </select>
                                    </div>
                                    
                                </div>
                            </div> -->


                            <div class="col-md-12" >
                                <div class="form-group">
                                    <label class="col-md-3 control-label"><?php echo lang('offer_name');?></label>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control" name="offer_name" id="offer_name" placeholder="<?php echo lang('offer_name');?>" />
                                    </div>
                                    
                                </div>
                            </div>

                            

                            <div class="col-md-12" >
                                <div class="form-group">
                                    <label class="col-md-3 control-label"><?php echo lang('description');?></label>
                                    <div class="col-md-9">
                                        <textarea class="form-control" name="description" id="description" placeholder="<?php echo lang('description');?>"></textarea>

                                    </div>
                                    
                                </div>
                            </div>

                            <div class="col-md-12" >
                                
                                <div class="form-group">
                                    <label class="col-md-3 control-label"><?php echo lang('from_date'); ?></label>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control" name="from_date" id="from_date" placeholder="<?php echo lang('from_date'); ?>" readonly=""/>
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-12" >
                                <div class="form-group">
                                    <label class="col-md-3 control-label"><?php echo lang('to_date'); ?></label>
                                    <div class="col-md-9">
                                        <input type="text" class="form-control" name="to_date" id="to_date" placeholder="<?php echo lang('to_date'); ?>" readonly=""/>
                                    </div>
                                </div>
                            </div>
                            

                            <div class="space-22"></div>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal"><?php echo lang('reset_btn');?></button>
                    <button type="submit" id="submit" class="btn btn-primary" ><?php echo lang('submit_btn');?></button>
                </div>
            </form>
        </div> <!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div>
<script>
    $(document).ready(function(){
        $('#user_id').select2();
    });
    $("#to_date").datepicker({
        todayBtn: "linked",
        format: 'yyyy/mm/dd',
        keyboardNavigation: false,
        forceParse: false,
        calendarWeeks: true,
        autoclose: true,
        startDate: '-0m'
    });

    $("#from_date").datepicker({
        startDate: '-0m',
        format: 'yyyy/mm/dd',
        todayBtn: "linked",
        keyboardNavigation: false,
        forceParse: false,
        calendarWeeks: true,
        autoclose: true,
    });
</script>