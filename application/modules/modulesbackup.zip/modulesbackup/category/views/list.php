<style>
  #message_div{
    background-color: #ffffff;
    border: 1px solid;
    box-shadow: 10px 10px 5px #888888;
    display: none;
    height: auto;
    left: 36%;
    position: fixed;
    top: 20%;
    width: 40%;
    z-index: 1;
  }
  #close_button{
    right:-15px;
    top:-15px;
    cursor: pointer;
    position: absolute;
  }
  #close_button img{
    width:30px;
    height:30px;
  }    
  #message_container{
    height: 450px;
    overflow-y: scroll;
    padding: 20px;
    text-align: justify;
    width: 99%;
  }
  .edit-row{
    color :red;
    text-decoration: underline;
  }


</style>


<div class="row wrapper border-bottom white-bg page-heading">
  <div class="col-lg-10">
    <h2><?php echo (isset($headline)) ? ucwords($headline) : ""?></h2>
    <ol class="breadcrumb">
      <li>
        <a href="<?php echo site_url('admin/dashboard');?>"><?php echo lang('home');?></a>
      </li>
      <li>
        <a href="<?php echo site_url('category');?>"><?php echo lang('category_management');?></a>
      </li>
    </ol>
  </div>
  <div class="col-lg-2">

  </div>
</div>
<div class="wrapper wrapper-content animated fadeIn">
  <div class="row">
    <div class="col-lg-12">
      <div class="ibox float-e-margins">
        <div class="ibox-title">
          <div class="btn-group " href="#">
            <a href="javascript:void(0)"  onclick="open_modal('category')" class="btn btn-primary">
              <?php echo lang('add_category');?>
              <i class="fa fa-plus"></i>
            </a>
          </div>
        </div>
        <div class="ibox-content">
         <div class="row">
          <?php $message = $this->session->flashdata('success');
          if(!empty($message)):?><div class="alert alert-success">
          <?php echo $message;?></div><?php endif; ?>
          <?php $error = $this->session->flashdata('error');
          if(!empty($error)):?><div class="alert alert-danger">
          <?php echo $error;?></div><?php endif; ?>
          <div id="message"></div>
          <div class="col-lg-12" style="overflow-x: auto">
            <table class="table table-bordered table-responsive" id="common_datatable_cat">
              <thead>
                <tr>
                  <th><?php echo lang('serial_no');?></th>
                  <th><?php echo lang('category_name');?></th>
                  <th><?php echo lang('image');?></th>
                  <!-- <th><?php echo lang('subcategory_name');?></th> -->
                </tr>
              </thead>
              <tbody>
                <?php 

                if (isset($list) && !empty($list)):
                  $rowCount = 0;
                foreach ($list as $rows):
                  $rowCount++;
                ?>
                <tr>
                 <td><?php echo $rowCount; ?></td>

                 <td class="action_button"><?php echo $rows->category_name;?>
                   <br/>
                   <div class="visible_button">
                     <a href="javascript:void(0)" class="on-default edit-row" onclick="editFn('category','category_edit','<?php echo encoding($rows->id)?>');"><i class="fa fa-pencil-square" aria-hidden="true"></i>
                     </a>
                     <a href="javascript:void(0)" onclick="delFn('<?php echo CATEGORY_MANAGEMENT;?>','id','<?php echo encoding($rows->id); ?>','category','category/del')" class="on-default edit-row text-danger"><i class="fa fa-trash-o" aria-hidden="true"></i>
                     </a>
                   </div>

                   <br/>
                   <br/>
                 </td>

                 <td><img width="100" src="<?php if(!empty($rows->image)){echo base_Url().'uploads/category/'?><?php echo $rows->image;}else{echo base_url().DEFAULT_NO_IMG_PATH;}?>" /></td>

                   <!-- <td>
                     
                 </td> -->

               </tr>
             <?php endforeach; endif;?>
           </tbody>
         </table>
       </div>
     </div>
   </div>
   <div id="form-modal-box"></div>
 </div>
</div>
</div>
<div id="message_div">
  <span id="close_button"><img src="<?php echo base_url();?>backend_asset/images/close.png" onclick="close_message();"></span>
  <div id="message_container"></div>
</div>