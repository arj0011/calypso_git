<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Partypackage extends Common_Controller { 
  public $data = array();
  public $file_data = "";
  public $element = array();
  public function __construct() {
    parent::__construct();
    $this->is_auth_admin();
  }

     /**
     * @method index
     * @description listing display
     * @return array
     */
     
    public function index() {

      $this->data['parent'] = "Food Items";
      $this->data['title'] = "Party Package";
      $option = array('table'=>PARTYPACKAGE,'where'=>array('status'=>1));
      $results_details = $this->common_model->customGet($option);
      
      if(!empty($results_details)){
        foreach($results_details as $row){
          $sql = "SELECT cm.id,cm.category_name,pc.items_id,pc.item_limit
                  FROM ".CATEGORY_MANAGEMENT." AS cm
                  INNER JOIN ".PACKAGECATEGORY." AS pc ON pc.category_id = cm.id
                  WHERE pc.package_id = $row->id";
          $query = $this->db->query($sql);
          $details = $query->result();

          if(!empty($details)){
            foreach($details as $detail){
              $itemID = $detail->items_id;
              $q = "SELECT id,item_name FROM ".ALLACART." WHERE id IN($itemID)";
              $qr = $this->db->query($q);
              $itemdata = $qr->result_array();
              $detail->itemdata = $itemdata;
            }
          }
          $row->category_data[] = $details;
        } 
      }
      $this->data['list'] = $results_details;
     // p($this->data['list']);
      $this->load->admin_render('list', $this->data, 'inner_script');
    }


    /**
     * @method open_model
     * @description load model box
     * @return array
     */

    function open_model() {
      $this->data['title'] = lang("add_party_package");
      $this->data['category'] = $this->db->get(CATEGORY_MANAGEMENT)->result();
      $this->load->view('add', $this->data);  
    }

    public function hierarchicalRenderer($list,$level=0){ 
      $element = [];
      if($list==''){
        return false;
      }else{
        foreach($list as $i=>$v){ 
          $temp = clone $v;
          if($level>0){ 
            $levelShower = '';
            for($i=0;$i<$level;$i++){
              $levelShower .= '- ';
            }
            $temp->category_name = $levelShower.''.$temp->category_name;
          }  
          unset($temp->childern);
          $this->element[] = $temp;
          if(isset($v->childern)){ 
            $this->hierarchicalRenderer($v->childern,$level+1);
          }
        }
        return $this->element;
      } 
    }


    /**
     * @method cms_add
     * @description add dynamic rows
     * @return array
     */
    public function item_add() {
      
      $this->form_validation->set_rules('food_name', lang('package_name'), 'required|trim');
      $this->form_validation->set_rules('description', lang('package_description'), 'required|trim');
      $this->form_validation->set_rules('price', lang('package_price'), 'required|trim');
      $this->form_validation->set_rules('gender', lang('gender_pref'), 'required|trim');
      $this->form_validation->set_rules('age_pref', lang('age_pref'), 'required|trim');

      if($this->form_validation->run() == true) {
        $this->filedata['status'] = 1;
        $image = "";
        if (!empty($_FILES['image']['name'])) {
          $this->filedata = $this->commonUploadImage($_POST, 'partypackage', 'image');
          if ($this->filedata['status'] == 1) {
            $image = $this->filedata['upload_data']['file_name'];
          }
        }

        if ($this->filedata['status'] == 0) {
          $response = array('status' => 0, 'message' => $this->filedata['error']);  
        }else{
          $current_date=date('Y-m-d');
          $user_id =array();
          
          $food_name = $this->input->post('food_name');
          $price = $this->input->post('price');
          $description = $this->input->post('description');
          $gender = $this->input->post('gender');
          $age_pref = $this->input->post('age_pref');
          
          $food_name = $this->security->xss_clean($food_name);
          $price   = $this->security->xss_clean($price);
          $description = $this->security->xss_clean($description);
        
          $option = array('table' => PARTYPACKAGE,
           'select' => 'item_name',
           'where' => array('item_name'=> $food_name)
          );

          $packagedata = $this->common_model->customGet($option);
          if(empty($packagedata)){  
              $options_data = array(
                'item_name'   => $food_name,
                'price'       => $price,
                'description' => $description,
                'image'       => $image,
                'gender_pref' => $gender,
                'age_pref'    => $age_pref,
                'created'=> datetime(),
                'status'      => 1,
              );
              

              $option = array('table' => PARTYPACKAGE, 'data' => $options_data);
              $package_id = $this->common_model->customInsert($option); 
              
              if($package_id) {
                /*Insert Data into package category table*/
                $category = $this->input->post('category');
                $limit = $this->input->post('limit');
                $itemids = $this->input->post('itemids');
               
                $i=0;
                if(!empty($category)){
                  foreach($category as $val){
                    $itmstr = '';
                    foreach($itemids[$val] as $v){
                      $itmstr .= $v.',';
                    }
                    $itemstr = rtrim($itmstr,',');
                    $insertArr[] = array(
                      'package_id'=>1,
                      'category_id'=>$val,
                      'items_id'=> $itemstr,
                      'item_limit'=>$limit[$i]
                    );
                    $i++;
                  }
                  
                  $package_category = $this->common_model->insertBulkData(PACKAGECATEGORY,$insertArr);   
                }
                //end

                $response = array('status' => 1, 'message' => lang('food_success'), 'url' => base_url('partypackage'));
              }else {
                $response = array('status' => 0, 'message' => lang('food_failed'));
              }
          }else{
            $response = array('status' => 0, 'message' => lang('food_exist'));
          }
        }
      } else {
        $messages = (validation_errors()) ? validation_errors() : '';
        $response = array('status' => 0, 'message' => $messages);
      }
      echo json_encode($response);
    }

    /**
     * @method cms_edit
     * @description edit dynamic rows
     * @return array
     */
    public function item_edit() {
      $this->data['title'] = lang("edit_food");
      $id = decoding($this->input->post('id'));
      if (!empty($id)) {

        $query = "select * from category_management where id NOT IN(select parent_id from category_management)";
       $this->data['category'] =  $this->common_model->customQuery($query);

        $option = array(
          'table' => FOODITEMS,
          'where' => array('id' => $id),
          'single' => true
          );
        $results_row = $this->common_model->customGet($option);
        if (!empty($results_row)) {
          $this->data['results'] = $results_row;
          if($results_row->type == 'alla_cart'){
            $this->load->view('alla_cart_edit', $this->data);  
          }
          if($results_row->type == 'food_parcel'){
            $option =array(
              'table' => FOODITEMS,
              'select'=> '*',
              'where' => array('status'=>1,'type'=>'alla_cart')
              );
            $this->data['pack_items'] = $this->common_model->customGet($option);
            $this->load->view('food_parcel_edit', $this->data);  
          }
          if($results_row->type == 'party_package'){
            $this->load->view('party_package_edit', $this->data);  
          }
        } else {
          $this->session->set_flashdata('error', lang('not_found'));
          redirect('product');
        }
      } else {
        $this->session->set_flashdata('error', lang('not_found'));
        redirect('fooditems/alla_cart');
      }
    }

    /**
     * @method cms_update
     * @description update dynamic rows
     * @return array
     */
    public function item_update() {

      if($this->input->post('item_type') == 'alla_cart'):
        $this->form_validation->set_rules('category_id', lang('select_category'), 'required|trim');
      endif;
      $this->form_validation->set_rules('food_name', lang('food_name'), 'required|trim');
      $this->form_validation->set_rules('price', lang('price'), 'required|trim');


      $where_id = $this->input->post('id');
      if ($this->form_validation->run() == FALSE):
        $messages = (validation_errors()) ? validation_errors() : '';
        $response = array('status' => 0, 'message' => $messages);
      else:
        $this->filedata['status'] = 1;
        $image = $this->input->post('exists_image');
        if (!empty($_FILES['image']['name'])) {
          $this->filedata = $this->commonUploadImage($_POST, 'fooditems', 'image');
          if ($this->filedata['status'] == 1) {
            $image = $this->filedata['upload_data']['file_name'];
            delete_file($this->input->post('exists_image'), FCPATH."uploads/fooditems/");
          }
        }
        if ($this->filedata['status'] == 0) {
          $response = array('status' => 0, 'message' => $this->filedata['error']);  
        }else{

          $food_name = $this->input->post('food_name');
          $price = $this->input->post('price');
          $description = $this->input->post('description');
          
          $food_name = $this->security->xss_clean($food_name);
          $price   = $this->security->xss_clean($price);
          $description = $this->security->xss_clean($description);
          
          $item_type = $this->input->post('item_type');
          $option = array('table' => FOODITEMS,
            'select' => 'item_name',
            'where' => array('id !='=>$where_id ,'item_name'=> $food_name)
          );
          $foods = $this->common_model->customGet($option);
          if(empty($foods)){
              $options_data = array(
                'item_name'      => $food_name,
                'price'          => $price,
                'description'    => $description,
                'image'          => $image
              );

              //In alla cart
              if(!empty($this->input->post('category_id')) && $item_type == 'alla_cart'){
                $category_id = $this->input->post('category_id');
                $category_id   = $this->security->xss_clean($category_id);
                $options_data['category_id'] = $this->input->post('category_id');
              }


              //in case of food parcel
              if(!empty($this->input->post('pack_items'))){
                $parcel_items_id = implode(',',$this->input->post('pack_items'));  
                $options_data['parcel_items_id'] = $parcel_items_id;
              }

              $option = array(
                'table' => FOODITEMS,
                'data' => $options_data,
                'where' => array('id' => $where_id)
                );
              
              $update = $this->common_model->customUpdate($option);
              if($item_type == 'alla_cart'){
                  $url = 'alla_cart';
              }
              if($item_type == 'party_package'){
                  $url = 'party_package';
              }
              if($item_type == 'food_parcel'){
                  $url = 'food_parcel';
              }
              $response = array('status' => 1, 'message' => lang('food_success_update'), 'url' => base_url('fooditems').'/'.$url);
          }else{
            $response = array('status' => 0, 'message' => lang('product_exist'));
          }
        }
      endif;
      echo json_encode($response);
    }

  function del() {
        $response = "";
        $id = decoding($this->input->post('id')); // delete id
        $table = $this->input->post('table'); //table name
        $id_name = $this->input->post('id_name'); // table field name
        if (!empty($table) && !empty($id) && !empty($id_name)) { 

            $option = array(
                'table' => $table,
                'where' => array($id_name => $id)
            );
            $delete = $this->common_model->customDelete($option);
            if ($delete) {
                $response = 200;
            } else
                $response = 400;
        }else {
            $response = 400;
        }
        echo $response;
    }

    public function edit_status() {
        $response = "";
        $id = $this->input->post('id'); // delete id
        $status = $this->input->post('status'); 
        if($status == 1){
          $flag = 0;
        }
        if($status == 0){
          $flag = 1;
        }
        
        if (!empty($id)) { 
      
          $options_data = array('status' => $flag);
          $option = array(
              'table' => PARTYPACKAGE,
              'data' => $options_data,
              'where' => array('id' => $id)
              );
          $update = $this->common_model->customUpdate($option);

          if($update) {
              $response = 200;
          } else
              $response = 400;
        }else {
            $response = 400;
        }
        echo $response;
    }


    public function get_items_by_catid(){
      $data = array();
      $category_id = $this->input->post('id');
      //print_r($category_id);die;
      $this->db->select('id,item_name');
      $data['data'] = $this->db->get_where(ALLACART,array('category_id'=>$category_id,'status'=>1))->result();
      if(!empty($data['data'])){
        $this->data['cat_items'] = $data['data'];
        $this->data['count'] = $this->input->post('count');
        $this->data['categoryID'] = $category_id;
        $this->load->view('cat_items_dropdown', $this->data); 
      }
    }
    public function get_all_items(){
      $data = array();
      $this->data['count'] = $this->input->post('count');
      
      if(!empty($_POST['globlcatArr'])):
        $str = '';
        foreach($_POST['globlcatArr'] as $val):
          $str .= $val.',';
          endforeach;
          $str = rtrim($str,',');  
      endif;
      $sql = "SELECT * FROM ".CATEGORY_MANAGEMENT." WHERE id NOT IN(".$str.")";
      $query = $this->db->query($sql);
      $this->data['category'] = $query->result();
      if(!empty($this->data['category'])){
        $this->load->view('all_items_dropdown', $this->data); 
      }
    }


}
