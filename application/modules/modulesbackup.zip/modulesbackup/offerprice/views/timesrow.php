<!-- This page append in fulldiv(dayaccordian.php) -->

<div class="col-md-3">
  <input type="text" placeholder="Start time" name="<?php echo $day;?>_start_time[]" class="form-control clockpicker" />  
</div>
<div class="col-md-3">    
  <input type="text" placeholder="End time" name="<?php echo $day;?>_end_time[]" class="form-control clockpicker" />
</div>
<div class="col-md-3">    
  <input type="text" placeholder="Price" name="<?php echo $day;?>_price[]" class="form-control" />
</div>
<div class="col-md-3">    
  <button type="button" class="btn btn-primary AddPrice">+</button>
</div>

<script type="text/javascript">
    $('.clockpicker').clockpicker({
      twelvehour: false,
      autoclose: true
    });
</script>