<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Offerprice extends Common_Controller { 
  public $data = array();
  public $file_data = "";
  public $element = array();
  public function __construct() {
    parent::__construct();
    $this->is_auth_admin();
  }

  /*OFFER PRICE RELATED METHODS*/

  /**
   * @method index
   * @description listing display
   * @return array
  */
     
  public function index($item_id) {
    $this->data['parent'] = "Offer Price";
    $this->data['title'] = "Offer Price";
    $this->data['week'] = array('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday');
    $item_id = decoding($item_id);
    $option = array(
      'table'   => ITEMDATES.' as idt',
      'select'  => 'idt.id,start_date,end_date,day',
      'join'    => array(ITEMSDATESDAY.' as idy'=>'idy.item_dates_id = idt.id'),
      'where'   => array('idt.item_id ='=>$item_id),
      'order'   => array('idt.start_date' => 'DESC'),
      'group_by'=> 'idt.id'
    );
    $this->data['datesData'] = $this->common_model->customGet($option);
    $this->load->admin_render('list', $this->data, 'inner_script');
  }


    

  /*public function setpricevariation($item_id=''){
    $this->data['parent'] = "Food Items";
    $this->data['title'] = "Alla Cart | Price Variation";
    $this->data['week'] = array('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday');
    $item_id = decoding($item_id);
    $option = array(
      'table'   => ITEMDATES.' as idt',
      'select'  => 'idt.id,start_date,end_date,day',
      'join'    => array(ITEMSDATESDAY.' as idy'=>'idy.item_dates_id = idt.id'),
      'where'   => array('idt.item_id ='=>$item_id),
      'order'   => array('idt.start_date' => 'DESC'),
      'group_by'=> 'idt.id'
    );
    $this->data['datesData'] = $this->common_model->customGet($option);
    $this->load->admin_render('setprice', $this->data, 'inner_script');
  }*/


  public function addprice(){
    $this->form_validation->set_rules('start_date', lang('start_date'), 'required|trim');
    $this->form_validation->set_rules('end_date', lang('end_date'), 'required|trim');
    
    $item_id = $this->input->post('item_id');
      
    //keep it for redirect
    $itm_id = $item_id;
    
    if($this->form_validation->run() == true){
      $start_date = $this->input->post('start_date');
      $end_date = $this->input->post('end_date');
       
      
      $start_date   = $this->security->xss_clean($start_date);
      $end_date   = $this->security->xss_clean($end_date);
      $item_id = decoding($item_id);

      $sql = "SELECT id FROM ".ITEMDATES." WHERE item_id = ".$item_id." AND (end_date <= '".$end_date."' and start_date >= '".$start_date."')";

      $existdate = $this->common_model->customQuery($sql,true);
      if(empty($existdate)){
        $options_data = array(
            'item_id'     => $item_id,
            'start_date'  => $start_date,
            'end_date'    => $end_date
          );
        $option = array('table' => ITEMDATES, 'data' => $options_data);
        $itemdates_id = $this->common_model->customInsert($option); 
        if($itemdates_id){
          $dayArr = $this->input->post('day');
          if(!empty($dayArr)){
            foreach ($dayArr as $day) {
              $option_data = array(
                'item_dates_id' => $itemdates_id,
                'day'           => $day
              );    
              $options = array('table' => ITEMSDATESDAY, 'data' => $option_data);
              $itemdatesday_id = $this->common_model->customInsert($options);
              if($itemdatesday_id){
                $count = count($_POST[$day.'_start_time']);
                for($i = 0;$i < $count;$i++){
                  $start_time = $_POST[$day.'_start_time'][$i];
                  $end_time = $_POST[$day.'_end_time'][$i];
                  $price = $_POST[$day.'_price'][$i];
                  
                  $opt_data = array(
                    'item_dates_id'     => $itemdates_id,
                    'item_dates_day_id' => $itemdatesday_id,
                    'start_time'        => $start_time, 
                    'end_time'          => $end_time,
                    'price'             => $price
                  );
                  $opts = array('table' => ITEMSDATESDAYSPRICE, 'data' => $opt_data);
                  $itemdatesdaytime_id = $this->common_model->customInsert($opts);      
                }
              }  
            }
            $this->session->set_flashdata('success', lang('price_success'));
            redirect('offerprice/'.$itm_id);
          } 
        }else{
          $this->session->set_flashdata('error', lang('price_failed'));
          redirect('offerprice/'.$itm_id);
        }
      }else{
        $this->session->set_flashdata('error', 'Price already exist on these dates');
        redirect('offerprice/'.$itm_id);
      }
    }else {
      $messages = (validation_errors()) ? validation_errors() : '';
      $this->session->set_flashdata('error', $messages);
      redirect('offerprice/'.$itm_id);
    }  

  }

  /*Load accordian according to date difference and day*/  
  public function getdatediff(){
    $start_date = $this->input->post('start_date');
    $end_date = $this->input->post('end_date');
    $item_id = $this->input->post('item_id');
    $item_id = decoding($item_id);
    $dayDatesArr = date_difference($start_date,$end_date);    
    if(!empty($dayDatesArr)){
      $this->data['week'] = array('Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday');
      $this->data['daysArr'] = array_column($dayDatesArr,'day');
      $this->load->view('dayaccordian',$this->data);
    }
  }  

  /*Load Times row inside accordian according to day*/
  public function addtimerow(){
    $this->data['day'] = $this->input->post('day');
    $this->load->view('timesrow',$this->data);
  }


  function open_daytime_model() {
    $this->data['title'] = lang("add_food");
    $item_dates_id = $this->input->post('item_dates_id');
    $option = array(
      'table'   => ITEMDATES.' AS idt',
      'select'  => 'idy.id AS items_dates_day_id,idy.day',
      'join'    => array(ITEMSDATESDAY.' as idy'=>'idy.item_dates_id = idt.id'),
      'where'   => array('idt.id ='=>$item_dates_id)
    );
    $detail_data = $this->common_model->customGet($option);
    if(!empty($detail_data)){
      foreach ($detail_data as $value) {
        $opt = array(
        'table'   => ITEMSDATESDAY.' AS idy',
        'select'  => 'idy.id AS items_days_id,idyp.start_time,idyp.end_time,idyp.price',
        'join'    => array(ITEMSDATESDAYSPRICE.' as idyp'=>'idyp.item_dates_day_id = idy.id'),
        'where'   => array('idy.id=' => $value->items_dates_day_id)
      );
        $detailed_data = $this->common_model->customGet($opt);       
        if(!empty($detailed_data)){
          foreach($detailed_data as $tymprice){
            $finalArr[$value->day][] = $tymprice;
          }
        }
      }
      $this->data['days_Data'] = $finalArr;  
    } 
    $this->load->view('datetimemodel', $this->data);  
    
  }


  function del() {
        $response = "";
        $id = decoding($this->input->post('id')); // delete id
        $table = $this->input->post('table'); //table name
        $id_name = $this->input->post('id_name'); // table field name
        if (!empty($table) && !empty($id) && !empty($id_name)) { 

            $option = array(
                'table' => $table,
                'where' => array($id_name => $id)
            );
            $delete = $this->common_model->customDelete($option);
            if ($delete) {
                $response = 200;
            } else
                $response = 400;
        }else {
            $response = 400;
        }
        echo $response;
    }


    public function hierarchicalRenderer($list,$level=0){ 
      $element = [];
      if($list==''){
        return false;
      }else{
        foreach($list as $i=>$v){ 
          $temp = clone $v;
          if($level>0){ 
            $levelShower = '';
            for($i=0;$i<$level;$i++){
              $levelShower .= '- ';
            }
            $temp->category_name = $levelShower.''.$temp->category_name;
          }  
          unset($temp->childern);
          $this->element[] = $temp;
          if(isset($v->childern)){ 
            $this->hierarchicalRenderer($v->childern,$level+1);
          }
        }
        return $this->element;
      } 
    }

}
