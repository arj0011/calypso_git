<!-- This page append in fulldiv(dayaccordian.php) -->
<div class="clearfix"></div>
<div class="col-md-3">
  <input type="text" placeholder="Start time" required id="st_<?php echo $day;?>_<?php echo $button_count;?>"  name="<?php echo $day;?>_start_time[]" class="form-control clockpicker" />  
</div>
<div class="col-md-3">    
  <input type="text" placeholder="End time" required id="et_<?php echo $day;?>_<?php echo $button_count;?>" name="<?php echo $day;?>_end_time[]" class="form-control clockpicker" />
</div>
<div class="col-md-3">    
  <input type="text" placeholder="Price" required data-rule-number="true" id="pr_<?php echo $day;?>_<?php echo $button_count;?>" name="<?php echo $day;?>_price[]" class="form-control" />
</div>
<div class="col-md-3">    
  <button type="button" data-buttonday="<?php echo $day;?>" id="<?php echo $day;?>_<?php echo $button_count;?>" class="btn btn-primary AddPrice">+</button>
  <button type="button" data-buttonday="<?php echo $day;?>" data-del-button-count="<?php echo $button_count;?>" class="btn btn-danger RemovePrice">-</button>
</div>

<script type="text/javascript">
    $('.clockpicker').clockpicker({
      twelvehour: false,
      autoclose: true
    });
    $(".clockpicker").keydown(false);
</script>