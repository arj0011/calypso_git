<div class="col-lg-12">
  <div class="panel-group" id="accordion">

  <?php 
    $i = 0;
    $j = 1;
    // foreach($datedaysArr as $datedays):
    foreach($week as $day):

      if(in_array($day, $daysArr)){
  ?>
  <div class="panel panel-default">
    <div class="panel-heading">
    <h4 class="panel-title">
      <a data-toggle="collapse" data-parent="#accordion" href="#<?php echo $day;?>"><?php echo $day;?></a>
    </h4>
    </div>
    <div id="<?php echo $day;?>" class="panel-collapse collapse">
      <div class="panel-body">
          <input type="hidden" name="day[]" value="<?php echo $day;?>" />
          <?php
            /*if(!empty($daysData)):
              foreach($daysData as $dy):
                if($dy->day == 'Monday'){

                }
                endforeach;
              endif;*/
          ?>
          <div class="fulldiv">
            <div class="col-md-3">
              <input type="text" placeholder="Start time" required id="st_<?php echo $day;?>_0" name="<?php echo $day;?>_start_time[]" class="form-control clockpicker" />  
            </div>
            <div class="col-md-3">    
              <input type="text" placeholder="End time" required id="et_<?php echo $day;?>_0" name="<?php echo $day;?>_end_time[]" class="form-control clockpicker" />
            </div>
            <div class="col-md-3">    
              <input type="text" placeholder="Price" required data-rule-number="true" id="pr_<?php echo $day;?>_0" name="<?php echo $day;?>_price[]" class="form-control" />
            </div>
            <div class="col-md-3">    
              <button type="button" class="btn btn-primary AddPrice" id="<?php echo $day;?>_0" data-buttonday="<?php echo $day;?>">+</button>
              
            </div>

            <!-- Append here nex row (load new view timesrow.php -->

          </div>
  
        <!-- </form> -->
      </div>
    </div>
  </div>
  <?php }$i++;$j++;endforeach;?>
  </div>
</div>
<script type="text/javascript">
    $('.clockpicker').clockpicker({
      twelvehour: false,
      autoclose: true
    });
$(".clockpicker").keydown(false);
</script>