<script>

/*Start*/
jQuery('body').on('click', '#offerpriceSubmit', function () {
    /*var button    = $(this).attr('id').split('_')[1];*/

    /****How to add element in a form dynamically*****/

    /*$("<input type='hidden' value='"+start_date+"' />")
     .attr("id", "startdate")
     .attr("name", "startdate")
     .appendTo(this.form);
     $("<input type='hidden' value='"+end_date+"' />")
     .attr("id", "enddate")
     .attr("name", "enddate")
     .appendTo(this.form);*/

     /******************End***************************/
    
    var form_name = this.form.id;
    var start_date  = $('#start_date').val();
    var end_date    = $('#end_date').val();

    $("#"+form_name).validate({
        ignore: "",
        rules: {
            start_date: "required",
            end_date: "required"
        },
        messages: {
            start_date: '<?php echo lang('start_date_req');?>',
            end_date: '<?php echo lang('end_date_req');?>'          
        },
        submitHandler: function (form) {
            $(form).ajaxSubmit({
            });
        }
    });
});
/*End*/


jQuery('body').on('change', '.input_img2', function () {

    var file_name = jQuery(this).val();
    var fileObj = this.files[0];
    var calculatedSize = fileObj.size / (1024 * 1024);
    var split_extension = file_name.split(".");
    var ext = ["jpg", "gif", "png", "jpeg"];
    if (jQuery.inArray(split_extension[1].toLowerCase(), ext) == -1)
    {
        $(this).val(fileObj.value = null);
        //showToaster('error',"You Can Upload Only .jpg, gif, png, jpeg  files !");
        $('.ceo_file_error').html('<?php echo lang('image_upload_error'); ?>');
        return false;
    }
    if (calculatedSize > 1)
    {
        $(this).val(fileObj.value = null);
        //showToaster('error',"File size should be less than 1 MB !");
        $('.ceo_file_error').html(' 1MB');
        return false;
    }
    if (jQuery.inArray(split_extension[1].toLowerCase(), ext) != -1 && calculatedSize < 10)
    {
        $('.ceo_file_error').html('');
        readURL(this);
    }
});

function readURL(input) {
    var cur = input;
    if (cur.files && cur.files[0]) {
        var reader = new FileReader();
        reader.onload = function (e) {
            $(cur).hide();
            $(cur).next('span:first').hide();
            $(cur).next().next('img').attr('src', e.target.result);
            $(cur).next().next('img').css("display", "block");
            $(cur).next().next().next('span').attr('style', "");
        }
        reader.readAsDataURL(input.files[0]);
    }
}

jQuery('body').on('click', '.remove_img', function () {
    var img = jQuery(this).prev()[0];
    var span = jQuery(this).prev().prev()[0];
    var input = jQuery(this).prev().prev().prev()[0];
    jQuery(img).attr('src', '').css("display", "none");
    jQuery(span).css("display", "block");
    jQuery(input).css("display", "inline-block");
    jQuery(this).css("display", "none");
    jQuery(".image_hide").css("display", "block");
    jQuery("#news_image").val("");
});

       
function show_message(msg) {
        var Base64 = {_keyStr: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=", encode: function (e) {
                var t = "";
                var n, r, i, s, o, u, a;
                var f = 0;
                e = Base64._utf8_encode(e);
                while (f < e.length) {
                    n = e.charCodeAt(f++);
                    r = e.charCodeAt(f++);
                    i = e.charCodeAt(f++);
                    s = n >> 2;
                    o = (n & 3) << 4 | r >> 4;
                    u = (r & 15) << 2 | i >> 6;
                    a = i & 63;
                    if (isNaN(r)) {
                        u = a = 64
                    } else if (isNaN(i)) {
                        a = 64
                    }
                    t = t + this._keyStr.charAt(s) + this._keyStr.charAt(o) + this._keyStr.charAt(u) + this._keyStr.charAt(a)
                }
                return t
            }, decode: function (e) {
                var t = "";
                var n, r, i;
                var s, o, u, a;
                var f = 0;
                e = e.replace(/[^A-Za-z0-9\+\/\=]/g, "");
                while (f < e.length) {
                    s = this._keyStr.indexOf(e.charAt(f++));
                    o = this._keyStr.indexOf(e.charAt(f++));
                    u = this._keyStr.indexOf(e.charAt(f++));
                    a = this._keyStr.indexOf(e.charAt(f++));
                    n = s << 2 | o >> 4;
                    r = (o & 15) << 4 | u >> 2;
                    i = (u & 3) << 6 | a;
                    t = t + String.fromCharCode(n);
                    if (u != 64) {
                        t = t + String.fromCharCode(r)
                    }
                    if (a != 64) {
                        t = t + String.fromCharCode(i)
                    }
                }
                t = Base64._utf8_decode(t);
                return t
            }, _utf8_encode: function (e) {
                e = e.replace(/\r\n/g, "\n");
                var t = "";
                for (var n = 0; n < e.length; n++) {
                    var r = e.charCodeAt(n);
                    if (r < 128) {
                        t += String.fromCharCode(r)
                    } else if (r > 127 && r < 2048) {
                        t += String.fromCharCode(r >> 6 | 192);
                        t += String.fromCharCode(r & 63 | 128)
                    } else {
                        t += String.fromCharCode(r >> 12 | 224);
                        t += String.fromCharCode(r >> 6 & 63 | 128);
                        t += String.fromCharCode(r & 63 | 128)
                    }
                }
                return t
            }, _utf8_decode: function (e) {
                var t = "";
                var n = 0;
                var r = c1 = c2 = 0;
                while (n < e.length) {
                    r = e.charCodeAt(n);
                    if (r < 128) {
                        t += String.fromCharCode(r);
                        n++
                    } else if (r > 191 && r < 224) {
                        c2 = e.charCodeAt(n + 1);
                        t += String.fromCharCode((r & 31) << 6 | c2 & 63);
                        n += 2
                    } else {
                        c2 = e.charCodeAt(n + 1);
                        c3 = e.charCodeAt(n + 2);
                        t += String.fromCharCode((r & 15) << 12 | (c2 & 63) << 6 | c3 & 63);
                        n += 3
                    }
                }
                return t
            }}

        msg = Base64.decode(msg);
        $('#message_container').text(msg);
        $('#message_div').show();
}

function close_message(){
    $('#message_container').text('');
    $('#message_div').hide();
}

$('#common_datatable_product').dataTable({
    order: [],
    columnDefs: [ { orderable: false, targets: [4,5] } ]
});

//var statusFun = function (table, field, id, status,ctrl, method,param) {
var statusFun = function (id,status) {   
    var message = "";
    if (status == 1) {
        message = "<?php echo lang('deactive'); ?>";
    } else if (status == 0) {
        message = "<?php echo lang('active'); ?>";
    }
    bootbox.confirm({
        message: "Do you want to " + message + " it?",
        buttons: {
            confirm: {
                label: 'Ok',
                className: '<?php echo THEME_BUTTON; ?>'
            },
            cancel: {
                label: 'Cancel',
                className: 'btn-danger'
            }
        },
        callback: function (result) {
            if (result) {
                var url = "<?php echo base_url() ?>/allacart/edit_status";
                var ctrl = 'allacart';
                $.ajax({
                    method: "POST",
                    url: url,
                    data: {id: id,status: status},
                    success: function (response) {
                        if (response == 200) {
                            setTimeout(function () {
                                $("#message").html("<div class='alert alert-success'><?php echo lang('change_status_success'); ?></div>");
                            });
                            window.setTimeout(function () {
                                window.location.href = ctrl;
                            }, 2000);
                        }
                    },
                    error: function (error, ror, r) {
                        bootbox.alert(error);
                    },
                });
            }
        }
    });
}


jQuery(document).ready(function(){
    jQuery('#day').select2();
});

/******************************Start Date and End Date with Validation****************************/
$('#start_date').datepicker({autoclose:true,startDate: '-0m',format: 'yyyy-mm-dd',keyboardNavigation:false,minDate:new Date()
}).change(function(){
    if($('#end_date').val() != '' && $('#end_date').val() != undefined){
      var first =  $(this).val();
      var second =  $('#end_date').val();
      if(new Date(second).getTime() <= new Date(first).getTime()){
        // $('.start_date_validation').html('Start date should be less than end date');
        bootbox.alert('<?php echo lang('startdate_less');?>');
        $(this).val('');
        $("#acc").html('');
      }
    }
});
$('#end_date').datepicker({autoclose:true,startDate: '-0m',format: 'yyyy-mm-dd',keyboardNavigation:false,minDate:new Date()
}).change(function(){
    if($('#start_date').val() != '' && $('#start_date').val() != undefined){
      var first = $('#start_date').val();
      var second = $(this).val();
      if(new Date(first).getTime() >= new Date(second).getTime()){
        // $('.end_date_validation').html('End date should be greater than start date');
        bootbox.alert('<?php echo lang('enddate_greater');?>');
        $(this).val('');
        $("#acc").html(''); 
      }
    } 
});


$("#start_date" ).focus(function() {
    $('.start_date_validation').html('');
});
$( "#end_date" ).focus(function() {
    $('.end_date_validation').html('');
}); 


$('#end_date').datepicker().on('changeDate', function(e) {
    var start_date = $('#start_date').val();  
    var end_date = $(this).val();
    var item_id = $('#item_id').val();
    if((start_date != '' && start_date != null && start_date != undefined) && (end_date != '' && end_date != null && end_date != undefined)){
        
        $.ajax({
            method: "POST",
            url: '<?php echo base_url('allacart/validate_dates')?>',
            data: {start_date:start_date,end_date:end_date,item_id:item_id},
            success: function (response) {
                var obj = JSON.parse(response);
                if(obj.status == 1){
                    $.ajax({
                        method: "POST",
                        url: '<?php echo base_url('allacart/getdatediff')?>',
                        data: {start_date:start_date,end_date:end_date,item_id:item_id},
                        success: function (resp) {
                             $("#acc").html(resp);
                        },
                        error: function (error, ror, r) {
                            bootbox.alert(error);
                        },
                    });    
                }else{
                    bootbox.alert(obj.message);
                }
            },
            error: function (error, ror, r) {
                bootbox.alert(error);
            },
        });
    }
       
});

/*********************************************END**********************************************/


/**************** Add Time,Price Row *********************/
$(document).on('click','.AddPrice',function(){
    var buttonday = $(this).data('buttonday');
    var appnddiv = $(this).closest('.fulldiv');
    var btncount = $(this).attr('id').split('_')[1];

    var start_time = $('#st_'+buttonday+'_'+btncount).val();
    var end_time = $('#et_'+buttonday+'_'+btncount).val();
    var price = $('#pr_'+buttonday+'_'+btncount).val();
    
    if((start_time != '' && start_time != null && start_time != undefined) && (end_time != '' && end_time != null && end_time != undefined) && (price != '' && price != null && price != undefined)){

        $.ajax({
            method: "POST",
            url: '<?php echo base_url('allacart/addtimerow')?>',
            data: {day:buttonday,button_count:btncount},
            success: function (response) {
                appnddiv.append(response);
            },
            error: function (error, ror, r) {
                bootbox.alert(error);
            },
        });
    }
   
});

/***************************End****************************/

/***************** Remove Time,Price Row ******************/
$(document).on('click','.RemovePrice',function(){
    var buttonday = $(this).data('buttonday');
    // var appnddiv = $(this).closest('.fulldiv');
    var btncount = $(this).data('del-button-count');
    
    console.log('buttonday : '+buttonday);
    console.log('btncount : '+btncount);
    console.log('start_time : '+start_time);
    console.log('end_time : '+end_time);
    console.log('price : '+price);
    
    var start_time = $('#st_'+buttonday+'_'+btncount).remove();
    var end_time = $('#et_'+buttonday+'_'+btncount).remove();
    var price = $('#pr_'+buttonday+'_'+btncount).remove();
    var price = $('#'+buttonday+'_'+btncount).remove();// (+) button
    $(this).remove(); // (-) button
    
});
/***************************End****************************/


var opn_modal = function (controller,method,id = '') {
    $.ajax({
        url: '<?php echo base_url(); ?>' + controller +"/"+ method,
        type: 'POST',
        data: {'<?php echo $this->security->get_csrf_token_name(); ?>': '<?php echo $this->security->get_csrf_hash(); ?>',item_dates_id:id},
        success: function (data, textStatus, jqXHR) {
            $('#form-modal-box').html(data);
            $("#commonModal").modal('show');
        }
    });
}



</script>

