<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<title>404 Page Not Found</title>
<link href="<?php echo base_url(); ?>backend_asset/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
	<div class="container">
            <div class="row">
                 <div class="col-md-12">
                     <a href="<?php echo base_url().'admin/login';?>"><img class="img-responsive" src="<?php echo base_url().'backend_asset/images/4_404.jpg'?>" /></a>
                 </div>
            </div>
	</div>
</body>
</html>